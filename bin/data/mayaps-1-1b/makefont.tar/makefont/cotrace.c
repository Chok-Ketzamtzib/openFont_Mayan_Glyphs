/*                                                        */
/*   cotrace.c        version 1.13   June 6, 2014         */
/*                                                        */
/*   Compact Trace:                                       */
/*   Convertor BMP (1 bit per pixel) to a very short EPS  */
/*   or to a type1 charstring program                     */
/*                                                        */
/*   Author: S.Yu.Orevkov                                 */
/*           orevkov@picard.ups-tlse.fr                   */
/*                                                        */
/*   Changes:                                             */
/*             [versions 0.1-0.3 were called `ctrace' ]   */
/*             v 0.2:  treat big/little endian            */
/*             v 0.3:  Sqrt (now math libr isn't needed)  */
/*                                                        */
/*             v 1.0:  1. Renamed by `cotrace' because    */
/*                       `ctrace' is already used for     */
/*                        another project                 */
/*                     2. Added -s to  `usage()'          */
/*                     3. New default:  -r15              */
/*                     4. Removed  -m option              */
/*                                                        */
/*             v 1.1:  1. Bug "...)\" is fixed (_put_69_) */
/*                     2. Change of the orientation on    */
/*                        each curve                      */
/*                     3. CharString output               */
/*                                                        */
/*             v 1.11: 1. Usage and README updated        */
/*                                                        */
/*             v 1.12  1. Entierly white input is allowed */
/*                     2. Option -m (Mirror with respect  */
/*                        to the vertical axis)           */
/*                     3. Option -g nn (margins)          */
/*                     4. A space in `-r nn' is allowed   */
/*                                                        */
/*             v 1.13  1. Now the size of word and dword  */
/*                        should be _at_least_ 2 and 4.   */
/*                        In older versions they were     */
/*                        required to be exactly 2 and 4  */

    /* -> eps 2 bytes per control point */

#include <stdio.h>
#include <stdlib.h>

#define ABS(x) ((x)<0 ? -(x) : (x))
/* #define _CS_debug_ */

#define YES 1
#define NO  0
#define BLACK 0
#define WHITE 0x8000

                        /* masks for pxl[y][x]            */
#define COLOR    0x8000 /* B/W                            */
#define SCANNED  0x4000 /* used in fill()                 */
#define REGION   0x3fff /* connected monochrome component */

int tolerance = 5;      /* mesured in pixels */

#define MaxNumCurves 10000
#define StackSize    30000

#define  MaxWH  ((84*84)/2)

int BMP_ByteOrder = YES;   /* Big/Little Endian */

                                   /******************************/
                                   /*****                    *****/
                                   /*****   u s a g e (  )   *****/
                                   /*****                    *****/
                                   /******************************/
void usage( char *s ){ printf("\
cotrace:  convert monochrome bmp to a very short eps\n\
version 1.13\n\
\n\
Usage:\n\
  %s InputFile [options]\n\
\n\
Options:\n\
 -rnn  Remove monochrome regions whose outer perimeter\n\
       is less than  nn  (default: 15).\n\
 -b    Set BoundingBox to the minimal box containing black pixels.\n\
       By default, the width and height of the bitmap are used in bb.\n\
 -n    Forbid multiline strings in the output (if -c is not specified).\n\
 -s    Separate the output (if -c is not specified):\n\
       BoundingBox->*.bb prolog->*.pro body->*.bd\n\
 -c    type1 charstring output instead of EPS\n\
 -a    binary output (if -c option is specified)\n\
 -p    Create a proof file foo.prf (this is an EPS file)\n\
 -m    Mirror image with respect to the vertical axis\n\
 -gnn  Add margins of  nn  pixels width ( nn  may be negative).\n\
       If -b option is specified, then the margins are added to\n\
       the minimal box containing black pixels\n\
",
  s);
  exit(10);
}
/*-------------------------------------------------------*/
           /* parameters controled from the command line */
           /* and their default values                   */

int MinCurveLen = 15;  /* remove the regions whose outer */
                       /* perimeter is smaller than this */
                       /* -r option in the command line  */

int minBB = NO; /* YES: use min BB containing black pxls */
                /* NO : use BB given by bmp width/height */
                /* -b option in the command line         */

int AllowNewLine = YES;  /* allow newline character \ in */
                         /* strings in the output eps    */
                         /* -n  option                   */

int Type1CS = NO;    /* Type1 CharString output (no eps) */
int CS_bin = NO;     /* binary CharString output         */

int Proof = NO;      /* create proof.eps  ( -p option)   */

int SeparateOutput = NO;   /* -s  option                 */

int Mirror = NO;   /* mirror image wrt the vertical axis */

int MarginWidth = 0;       /* -gnn  option               */

/*-------------------------------------------------------*/

typedef unsigned long int dword; /* at least 32-bit word */
typedef unsigned short int word; /* at least 16-bit word */
typedef unsigned char byte;      /* at least  8-bit word */


                         /* BMP header:                 */
typedef struct{
      word  BM;          /* Signature: should be "BM"   */
      dword FileSize;    /* File size in bytes          */
      dword Dummy;       /* should be 0                 */
      dword DataOffset;  /* File offs to raster data    */

      dword Size40;      /* Size of info header = 40    */
      dword Width;       /* Bitmap width                */
      dword Height;      /* Bitmap height               */
      word Planes;       /* Number of planes = 1        */
      word BitCount;     /* Bits per pixel              */
      dword Compression; /* = 0 means no compression    */
      dword ImageSize;   /* (compressed) size of image  */
                         /* It is valid to set this 0   */
                         /* if Compression = 0          */
      dword XpixelsPerM; /* horizontal resolution px/m  */
      dword YpixelsPerM; /* vertical resolution px/m    */
      dword ColorsUsed;  /* Num of actually used colors */
      dword ColorsImportant; /* 0 = all                 */
} t_head;

char *palette;
size_t palette_size;
int inverse_color = NO;

t_head head;
byte s_head[54];
byte *raster;
word **pxl, *pxl_heap;
int WidthInDwords, WidthInBytes, Width, Height;
dword len_raster;

typedef struct{ int _10,_11,_12,_20,_21,_22; } t_matrix; 
t_matrix mat={0,1,0,0,0,1},mat1,mat2;
t_matrix matR={0, 0, 1,  0,-1, 0},
         matr={0, 0,-1,  0, 1, 0},
         matV={0,-1, 0,  0, 0, 1},
         matH={0, 1, 0,  0, 0,-1},
         matC={0,-1, 0,  0, 0,-1};

typedef int t_point_coord;
typedef struct{ t_point_coord x,y; } t_point;
t_point *pt_heap;
int PtHeapSize;
int pt_hp;          /* heap pointer */

t_point *curve[ MaxNumCurves ]; /* array of curves         */
int  curve_len[ MaxNumCurves ];
int  curve_dep[ MaxNumCurves ]; /* depth of the curve      */
t_point  IntPt[ MaxNumCurves ]; /* an interior point       */
int OuterCurve[ MaxNumCurves ]; /* the closest outer curve */
                         /* = -1 means the crv is exterior */

int nCurves;
t_point **scrv;

int **_2cr;  /* _2cr[i][j] is the 2-connectedness radius */
             /* of the j-th point of the i-th curve      */
int **_2ca;  /* _2ca[i][j] is the 2-c. angle */

int stack[ StackSize ];  /* stack for fill() */
int SP;                  /* stack pointer    */

int debug=NO;

int minX,minY,maxX,maxY; /* min bounding box for black pixels */
int mbbWidth, mbbHeight; /* its dimensions                    */

int bbWidth, bbHeight;   /* the bounding box in the eps file  */
int use_bb_offs = NO;

double ScaleFactor;    /* are used to scale max(Width,Height) */
int CS_bbX, CS_bbY;    /* to 1000 for Type1 CharString output */

int CS_X=0, CS_Y=0;    /* current point in CharString coord syst */

byte *CS_buf; int CS_buf_pt=0, CS_buf_size=10000;

/*--------------------------------------------------------*/
/*    Type 1 CharString Commands                          */

#define  CSC_hstem       1
#define  CSC_vstem       3
#define  CSC_hsbw       13
#define  CSC_endchar    14
#define  CSC_rlineto     5
#define  CSC_hlineto     6
#define  CSC_vlineto     7
#define  CSC_rrcurveto   8
#define  CSC_vhcurveto  30
#define  CSC_hvcurveto  31
#define  CSC_closepath   9
#define  CSC_rmoveto    21
#define  CSC_hmoveto    22
#define  CSC_vmoveto     4

/*--------------------------------------------------------*/
int cc[6];

/*--------------------------------------------------------*/
void err( char *s );
void err2( char *s1, char *s2 );
/* void usage( char *s ); */
void push( int x0, int x1, int y );
void pop( int *x0, int *x1, int *y );
void out_pxl( void );
void out_curves(void);
void fill( int x, int y, int c, int depth );
int fill_line( int x, int y, int dir, int c );
void trace(int x1,int y1,int c1,int x2,int y2,int c2,int nc);
double good_approx( t_point *crv, int len, int j0, int j1, 
          int x0,int y0,int x1,int y1,int x2,int y2,int x3,int y3 );
int b2_int( int c );
void transform( t_point *p, int *x, int *y );
void vector_transform( int x,int y, int *px, int *py );
void copy_matrix( t_matrix *src, t_matrix *dst );
void get_matrix( char *p );
void compose_matrices( t_matrix *A, t_matrix *B, t_matrix *C );
word  string2word( byte *s );
dword string2dword( byte *s );
double Sqrt_( double a );
void CS_num( int n );
void CS_byte( byte c );
void CS_point( int x, int y );
void CS_vpoint( int y );
void CS_hpoint( int x );
void CS_cmd( byte c );
int Check2cr( int ix0, int iy0, int r, int *a );
void Trace2cr( void );
void ToBlackPxl( int x, int y, int *xb, int *yb );
int PxlColor(int x, int y);
/*--------------------------------------------------------*/
FILE *in, *out, *out_bb, *out_body, *out_hdr, *out_proof; 
char *FileName;
                                       /*********************/
                                       /*                   */
                                       /*   M A I N (   )   */
                                       /*                   */
                                       /*********************/
/**** Example from T1Format.pdf ****
main(){
 CS_cmd(0); CS_cmd(0); CS_cmd(0); CS_cmd(0); 

 CS_num(50);  CS_num(800); CS_cmd(CSC_hsbw);
 CS_num(0);   CS_num(100); CS_cmd(CSC_vstem);
 CS_num(0);   CS_num(100); CS_cmd(CSC_hstem);
 CS_num(600); CS_num(100); CS_cmd(CSC_hstem);

 CS_num(0);                CS_cmd(CSC_hmoveto);
 CS_num(700);              CS_cmd(CSC_hlineto);
 CS_num(100);              CS_cmd(CSC_vlineto);
 CS_num(-600);             CS_cmd(CSC_hlineto);

 CS_num(500);              CS_cmd(CSC_vlineto);
 CS_num(600);              CS_cmd(CSC_hlineto);
 CS_num(100);              CS_cmd(CSC_vlineto);
 CS_num(-700);             CS_cmd(CSC_hlineto);

 CS_cmd(CSC_closepath);    CS_cmd(CSC_endchar);
}
****/

main( int argc, char *argv[] ){
  int x,y,i,j,X,Y,found; 
  byte b,c,mask;
  char *s;

  if( sizeof(word)<2 || sizeof(dword)<4 )err(
"C-compiler: sizeof(short int) and sizeof(int) should be at least 2 and 4"
  );

  /* Detect the byte order (Big/Little Endian) */
  {  dword dw=1; char *s; s=(char *)(&dw);
     BMP_ByteOrder = (*s == 1);
  }

  if( argc < 2 )usage( argv[0] );

                                        /***  get options  ***/
  j=0;
  for( i=1; i<argc; i++ ){
    if( argv[i][0] == '-' ){
      switch( argv[i][1] ){ int rc;
        case 'r': rc = 1;
          if( argv[i][2] ) s = argv[i]+2;
          else{ i++; if( i == argc ) rc = 0; else s = argv[i];}
          if( rc ) rc = sscanf( s, "%d", &MinCurveLen );
          if( rc == 0 )err(" -r  must be followed by an integer number");
          if( MinCurveLen < 0 )MinCurveLen = 0;
          break;
        case 'g': rc = 1;
          if( argv[i][2] ) s = argv[i]+2;
          else{ i++; if( i == argc ) rc = 0; else s = argv[i];}
          if( rc ) rc = sscanf( s, "%d", &MarginWidth );
          if( rc == 0 )err(" -g  must be followed by an integer number");
          break;
        case 'a': CS_bin = YES; CS_buf = (byte *)malloc( CS_buf_size ); break;
        case 'b': minBB          = YES; break;
        case 'c': Type1CS        = YES; break;
        case 'n': AllowNewLine   = NO;  break;
        case 'p': Proof          = YES; break;
        case 's': SeparateOutput = YES; break;
        case 'm': Mirror         = YES; break;
        default: usage( argv[0] );
      }
    }
    else{
      if( j>0 )usage( argv[0] );
      j=i;                 /* the j-th argument is not preceeded by '-' */
                           /* this must be the filename                 */
    }
  }
  if(j==0)usage( argv[0] );
  if( Type1CS ) SeparateOutput = NO;
  if( minBB && MarginWidth<0 )
    err("-b options requires the margin width ( -g ) non-negative");


                            /*** open the input file ***/
  in = fopen(argv[j],"r");
  if( in == NULL )err2("cannot open file",argv[1]);

                            /*** open the output files ***/
  
{ int n; byte *p=argv[j];

  for( n=0; n<1000; n++ ) if( p[n]==0 )break;
  if( SeparateOutput ){
     p[n-3] = 'p'; p[n-2] = 'r'; p[n-1] = 'o'; out_hdr  = fopen(p,"w");
     p[n-3] = 'b'; p[n-2] = 'b'; p[n-1] =  0;  out_bb   = fopen(p,"w");
                   p[n-2] = 'd';               out_body = fopen(p,"w");
  }

  if( Type1CS ){
     p[n-3] = 'b'; p[n-2] = 'b'; p[n-1] = 0;   out_bb = fopen(p,"w");
  }

  if( Proof ){ AllowNewLine = YES;
     p[n-3] = 'p'; p[n-2] = 'r'; p[n-1] = 'f'; out_proof = fopen(p,"w");
  }
}
                                  /*** read the BMP header ***/

#define _BadBMP_ err2( "bad BMP file", argv[1] );

/*  We do not read the header by the command  */
/*                                            */
/*      fread(head,sizeof(t_head),1,in);      */
/*                                            */
/*  because some C compilers, e.g., gcc       */
/*  align dwords to 4-byte borders            */
/*  So, we do like this:                      */

  if( fread(s_head,1,54,in) != 54 ) _BadBMP_


  head.FileSize       = string2dword( s_head+ 2 );
  head.Dummy          = string2dword( s_head+ 6 );
  head.DataOffset     = string2dword( s_head+10 );
  head.Size40         = string2dword( s_head+14 );
  head.Width  = Width = string2dword( s_head+18 );
  head.Height =Height = string2dword( s_head+22 );
  head.Planes         =  string2word( s_head+26 );
  head.BitCount       =  string2word( s_head+28 );
  head.Compression    = string2dword( s_head+30 );
  head.ImageSize      = string2dword( s_head+34 );
  head.XpixelsPerM    = string2dword( s_head+38 );
  head.YpixelsPerM    = string2dword( s_head+42 );
  head.ColorsUsed     = string2dword( s_head+46 );
  head.ColorsImportant= string2dword( s_head+50 );

                                      /*** check the header ***/
 {char NotSupp[]="are not supported";
  if( s_head[0] != 'B' || s_head[1] != 'M' ) _BadBMP_
  if( head.Dummy != 0 ) _BadBMP_
  if( head.Planes != 1 )err2("bmp with more than 1 planes",NotSupp); 
  if( head.BitCount != 1 )err2("bmp with more than 1 bit/pixel",NotSupp);
  if( head.Compression != 0 )err2("compressed bmp",NotSupp);
 }

                                         /*** read the palette ***/
  palette_size = (head.DataOffset) - 54;
  palette = (byte *)malloc(palette_size);
  if( fread(palette,1,palette_size,in) != palette_size ) _BadBMP_
  if( palette_size > 0 )inverse_color = palette[0];

                                      /*** read the raster ***/
  WidthInDwords = (Width - 1)/32 + 1;
  WidthInBytes  = (Width - 1)/8  + 1;
  raster = (byte *)malloc( len_raster = WidthInDwords*Height*4 );
  if( fread(raster,1,len_raster,in) != len_raster ) _BadBMP_

  pxl_heap = (word *)malloc( (Width+2) * (Height+2) * sizeof(word) );
  pxl = (word **)malloc( (Height+2) * sizeof(byte *) );

  pxl[0] = pxl_heap; 
  pxl[Height+1] = pxl_heap + (Height+1)*(Width+2);

 {int INVERSE = (inverse_color ? COLOR : 0);
  for( y=0; y < Height; y++ ){             /* rows */
    pxl[y+1] = pxl_heap + (y+1)*(Width+2) ;
    for( x=1,j=0; j < WidthInBytes; j++ ){
      b = raster[ j + y*WidthInDwords*4 ];
      for( mask=128; mask; mask=mask>>1 ){
        pxl[y+1][x++] = (( (b&mask) ? COLOR : 0 )^INVERSE) | REGION; 
        if( x > Width )break;
      }
    }
  }
 }
  free( raster );

                                       /*** add white frame ***/
  Width+=2; Height+=2;
  for( x=0; x<Width; x++ ) pxl[0][x] = pxl[Height-1][x] = WHITE|REGION;
  for( y=0; y<Height; y++ ) pxl[y][0] = pxl[y][Width-1] = WHITE|REGION;

   /*==============================================*/
   /*   Now the bitmap is read.                    */
   /*   pxl[y][x] is the color of the point (x,y)  */
   /*==============================================*/

                              /*** if -m option is on ***/
  if( Mirror ){ word *py, pxy;
    for( y=0; y<Height; y++ ){ py=pxl[y];
      for( x=0; x<Width/2; x++ ){
        pxy=py[x]; py[x]=py[Width-1-x]; py[Width-1-x]=pxy;
      }
    }
  }

                              /*** erase all 2x2 chessboards ***/
  found=YES;
  while( found ){ found=NO; word c;
    for( y=1; y<Height; y++ ) for( x=1; x<Width; x++ ){
      if( (c=pxl[y-1][x-1])==pxl[y-1][x] )continue;
      if( c==pxl[y][x-1] || c!=pxl[y][x] )continue;
      found=YES;
      pxl[y][x]=pxl[y-1][x]=pxl[y][x-1]=pxl[y-1][x-1]=WHITE|REGION;
    }
  }

                /***  change the color of each pxl to the color of   ***/
                /***  the majority of its (non-diagonal) neighbours  ***/
  found=YES;
  while( found ){word c1,c2,c3,c4; found=NO;
    for( y=1; y<Height-1; y++ ) for( x=1; x<Width-1; x++ ){
      c1 = pxl[y+1][x]; c2 = pxl[y-1][x]; c3 = pxl[y][x-1]; c4 = pxl[y][x+1];
      if( c1==c2 )if( c3==c1 || c4==c1 )pxl[y][x]=c1;
      if( c3==c4 )if( c1==c3 || c2==c3 )pxl[y][x]=c3;
    }
  }

                   /*** compute the bounding box for black pixels ***/
  minX=Width; minY=Height; maxY=maxX=-1; 
  for( x=0; x<Width; x++ )for( y=0; y<Height; y++ ){
    if( (COLOR & pxl[y][x]) == 0 ){
      if( x<minX ) minX=x;
      if( y<minY ) minY=y;
      if( x>maxX ) maxX=x;
      if( y>maxY ) maxY=y;
    }
  }
  if( maxX < minX ) mbbWidth  = mbbHeight = 0;
  else{
    mbbWidth  = maxX - minX + 1;
    mbbHeight = maxY - minY + 1;
  }

  if( ( mbbWidth > 0 &&
        ( MarginWidth < -minX || MarginWidth < maxX-Width +1 ||
          MarginWidth < -minY || MarginWidth < maxY-Height+1 ) )
      ||( 2*MarginWidth <= -Width )||( 2*MarginWidth <= -Height ) )
    err("Too wide negative margins");

  if( ! Type1CS ){
    if( mbbWidth > MaxWH || mbbHeight > MaxWH ){
      printf("Maximal supported width/height is %d pixels\n",MaxWH);
      exit(9);
    }
    if( maxX+MarginWidth>MaxWH || maxY+MarginWidth>MaxWH ) use_bb_offs = YES;
  }

  if( minBB ){ bbWidth = 2*mbbWidth; bbHeight = 2*mbbHeight; }
  else{ bbWidth = 2*Width; bbHeight = 2*Height; }


  PtHeapSize = Width*Height*2;
  pt_heap = (t_point *)malloc( PtHeapSize*sizeof(t_point) );
  nCurves = 0; pt_hp = 0;

                       /*** trace complete outline curves ***/ 

  if(debug)out_pxl();

  fill(0,0,0,0);
  for( i=0; i<nCurves; i++ ){
    fill( IntPt[i].x, IntPt[i].y, i+1, curve_dep[i]+1 );
  }

 /* shift the region numbers by one, so that they coinside */
 /* with the numbers of exterior boundary curves, and the  */
 /* number of the exterior region is the REGION-mask       */  

  for( x=0; x<Width; x++ ) for( y=0; y<Height; y++ ){
    if( (pxl[y][x] & REGION) == 0 ) pxl[y][x] = REGION | pxl[y][x];
    else pxl[y][x]--;
  }

 /***************************************************************/
 /******                                                   ******/
 /****** remove curves which are shorter than MinCurveLen  ******/
 /******                                                   ******/

 {int *del, *ind, r; word p; word newcolor;
  del = (int *)malloc( nCurves * sizeof(int *) );
  ind = (int *)malloc( nCurves * sizeof(int *) );
  for( i=0; i<nCurves; i++ )del[i] = (curve_len[i] < MinCurveLen);

  found=YES;  /** delete curves whose outer curves are deleted **/
  while(found){ found=NO;
    for( i=0; i<nCurves; i++ ){ if(del[i])continue;
      if( (j=OuterCurve[i]) == -1 )continue;
      if( del[j] )del[i] = YES;
    }
  }

  for( i=0; i<nCurves; i++ ){ if( !del[i] ){ ind[i]=-2; continue; }
    j=OuterCurve[i];
    while( YES ){
      if( j == -1 ){ ind[i] = -1; break; }
      if( !del[j] ){ ind[i] = j; break; }
      j = OuterCurve[j];
    }
  }

  for( x=0; x<Width; x++ ) for( y=0; y<Height; y++ ){
    if( (r = (p=pxl[y][x]) & REGION) == REGION )continue;
    newcolor = ( curve_dep[ind[r]]&1 ? WHITE : BLACK );
    if( del[r] ) pxl[y][x] = ((newcolor|SCANNED)&p) | ind[r];
  }

  j=0;
  for( i=0; i<nCurves; i++ ){ if( del[i] )continue;
    ind[i] = j;
    curve[j] = curve[i];
    curve_len[j]=curve_len[i];
    curve_dep[j]=curve_dep[i];
    IntPt[j].x = IntPt[i].x;
    IntPt[j].y = IntPt[i].y;
    OuterCurve[j++] = OuterCurve[i];
  }
  nCurves=j;

  for( x=0; x<Width; x++ ) for( y=0; y<Height; y++ ){
    if( (r = (p=pxl[y][x]) & REGION) == REGION )continue;
    if( !del[r] ) pxl[y][x] = ((COLOR|SCANNED)&p) | ind[r];
  }

  free( del ); free( ind );
 }
 /******                                                   ******/
 /******          short curves are removed                 ******/
 /******                                                   ******/
 /***************************************************************/


 /****************************************************************/
 /***                                                          ***/
 /***  Change the orientation of all curves (added 24.05.2007) ***/

 { int len,k; t_point_coord z;
   for( i=0; i<nCurves; i++ ){ len=curve_len[i];
     for( j=0; j+j < len; j++ ){ k=len-1-j;
       z=curve[i][j].x; curve[i][j].x=curve[i][k].x; curve[i][k].x=z;
       z=curve[i][j].y; curve[i][j].y=curve[i][k].y; curve[i][k].y=z;
     }
   }
 }
 /***                                                          ***/
 /****************************************************************/

  /***  Compute the 2-connectedness radii (2CR) along the   ***/
  /***  outline curves. The 2CR at a point p is the minimal ***/
  /***  such that the disk of radius r centered at p has a  ***/
  /***  single black component and a single white component ***/

  _2cr = (int **)malloc( nCurves * sizeof(int *) );
  _2ca = (int **)malloc( nCurves * sizeof(int *) );
  for(i=0; i<nCurves; i++){
     _2cr[i]=(int *)malloc(curve_len[i]*sizeof(int));
     _2ca[i]=(int *)malloc(curve_len[i]*sizeof(int));
  }
  Trace2cr();

                     /** translate all the curves if necessary **/
                     /** and change the BB by the MarginWidth  **/

  { int dx=0, dy=0, mw=MarginWidth;
    if( minBB || use_bb_offs ){ dx = -2*minX; dy = -2*minY; }
    if( ! use_bb_offs )       { dx += 2*mw;   dy += 2*mw;   }
    for( i=0; i<nCurves; i++ ){
      for( j=0; j<curve_len[i]; j++ ){
        curve[i][j].x += dx; curve[i][j].y += dy;
      }
    }
    bbWidth  += (4*mw);  minX += mw;
    bbHeight += (4*mw);  minY += mw;
  }


                                /* Print the header of eps file */
if( ! Type1CS ){

  printf("\
%%!PS-Adobe-3.0 EPSF-3.0\n\
%%%%Creator: Compact Trace (cotrace) v 1.12\n\
%%%%BoundingBox: 0 0 %d %d\n\
%%%%EndComments\n\
%%%%BeginProlog\n\
/g{get 42 sub dup 93 ge{1 sub}if}bind def\n\
/C{ dup 0 g 84 mul 1 index 1 g add 1 index 2 g 84 mul 2 index 3 g add\n\
    moveto 0 exch dup length 4 sub 4 exch getinterval\n\
    {   dup 94 ge{3 sub}if 80 sub\n\
        1 index 2 ge{3 index add}if\n\
        exch 1 add dup 6 eq{pop rcurveto 0}if\n\
    }forall pop closepath\n\
}bind def\n\
/f{fill}def/n{newpath}def\n", bbWidth, bbHeight );

   if( !AllowNewLine ) printf("\
/A{ ()exch\n\
    {   dup length 2 index length add string dup 4 3 roll\n\
        dup length 5 1 roll exch copy pop dup 4 2 roll putinterval\n\
    }forall C\n\
}bind def\n");

   printf("%%%%EndProlog\n");
   if( use_bb_offs ) printf( "%d %d translate\n", 2*minX, 2*minY );
   printf("n\n");


   if( SeparateOutput ){
      fprintf( out_bb, "0 0 %d %d\n", bbWidth, bbHeight );
      fprintf( out_hdr,"\
/g{get 42 sub dup 93 ge{1 sub}if}bind def\n\
/C{ dup 0 g 84 mul 1 index 1 g add 1 index 2 g 84 mul 2 index 3 g add\n\
    moveto 0 exch dup length 4 sub 4 exch getinterval\n\
    {   dup 94 ge{3 sub}if 80 sub\n\
        1 index 2 ge{3 index add}if\n\
        exch 1 add dup 6 eq{pop rcurveto 0}if\n\
    }forall pop closepath\n\
}bind def\n\
/f{fill}def/n{newpath}def\n");

      if( !AllowNewLine ) fprintf(out_hdr,"\
/A{ ()exch\n\
    {   dup length 2 index length add string dup 4 3 roll\n\
        dup length 5 1 roll exch copy pop dup 4 2 roll putinterval\n\
    }forall C\n\
}bind def\n");

      if( use_bb_offs ) fprintf( out_body, "%d %d translate\n", 2*minX, 2*minY );
      fprintf( out_body, "n\n");
   }
   
}  /* Matches to  "if( !Type1CS ){" */

else{
   if( bbWidth > bbHeight )ScaleFactor = 1000. / ((double)bbWidth);
   else                    ScaleFactor = 1000. / ((double)bbHeight);
   CS_bbX = ScaleFactor*bbWidth;
   CS_bbY = ScaleFactor*bbHeight;
   fprintf( out_bb, "0 0 %d %d\n", CS_bbX, CS_bbY );
   if(!CS_bin)putchar('<');

   CS_cmd(0); CS_cmd(0); CS_cmd(0); CS_cmd(0);   /* 4 random bytes */

   CS_num(0);  CS_num(CS_bbX);  CS_cmd( CSC_hsbw );
}


if( Proof ){
   if( ! Type1CS ){ fprintf(out_proof,"\
\
%%!PS-Adobe-3.0 EPSF-3.0\n\
%%%%Creator: Compact Trace (cotrace) v 1.12\n\
%%%%BoundingBox: 0 0 %d %d\n\
%%%%EndComments\n\
%%%%BeginProlog\n\
/g{get 42 sub dup 93 ge{1 sub}if}bind def\n\
/C{ dup dup 0 g 84 mul 1 index 1 g add 1 index 2 g 84 mul 2 index 3 g add\n\
    moveto 0 exch dup length 4 sub 4 exch getinterval\n\
    {   dup 94 ge{3 sub}if 80 sub\n\
        1 index 2 ge{3 index add}if\n\
        exch 1 add dup 6 eq{pop rcurveto 0}if\n\
    }forall pop closepath\n\
}bind def\n\
/bigpt{newpath x y moveto 3 3 rmoveto -6 0 rlineto 0 -6 \n\
  rlineto 6 0 rlineto closepath fill}bind def\n\
/rc{6 4 roll pts 4 2 roll pts 2 copy ptf/y exch y add def/x exch x add def}bind def\n\
/pt{newpath y add exch x add exch\n\
moveto 2 2 rmoveto -4 0 rlineto 0 -4 rlineto 4 0 rlineto closepath}bind def\n\
/pts{pt stroke}def/ptf{pt fill}def\n\
/f{fill]\n\
  { 1 0 0 setrgbcolor\n\
    dup 0 g 84 mul 1 index 1 g add 1 index 2 g 84 mul 2 index 3 g add\n\
    /y exch def/x exch def bigpt 0 exch dup length 4 sub 4 exch getinterval\n\
    {   dup 94 ge{3 sub}if 80 sub\n\
        1 index 2 ge{3 index add}if\n\
        exch 1 add dup 6 eq{pop rc 0}if\n\
    }forall pop closepath\n\
  }forall\n\
}def/n{[newpath}def\n", bbWidth, bbHeight );

      fprintf(out_proof,"%%%%EndProlog\n");
      if( use_bb_offs ) fprintf(out_proof, "%d %d translate\n", 2*minX, 2*minY );
      fprintf(out_proof,"0.9 setgray n\n");


   } /* matches to "if( ! Type1CS ){" */

   else{fprintf(out_proof,"\
\
%%!PS-Adobe-3.0 EPSF-3.0\n\
%%%%Creator: Compact Trace (cotrace) v 1.12\n\
%%%%BoundingBox: 0 0 %d %d\n\
%%%%EndComments\n\
%%%%BeginProlog\n\
/bigpt{newpath moveto 3 3 rmoveto -6 0 rlineto 0 -6 \n\
  rlineto 6 0 rlineto closepath fill}bind def\n\
/pt{newpath moveto 2 2 rmoveto -4 0 rlineto 0 -4 \n\
  rlineto 4 0 rlineto closepath}bind def\n\
/pts{pt stroke}bind def/ptf{pt fill}bind def\n\
/f{dup\n\
    newpath\n\
    {\n\
        {dup length 2 eq{dup 0 get exch 1 get moveto}\n\
            {dup 0 get exch dup 1 get exch dup 2 get exch dup \n\
                3 get exch dup 4 get exch 5 get curveto\n\
            }ifelse\n\
        }forall\n\
        closepath\n\
    }forall\n\
    0.9 setgray fill 1 0 0 setrgbcolor\n\
    {\n\
        {dup length 2 eq{dup 0 get exch 1 get bigpt}\n\
            {   dup 1 get exch dup 0 get 3 2 roll pts\n\
                dup 3 get exch dup 2 get 3 2 roll pts\n\
                dup 5 get exch dup 4 get 3 2 roll ptf\n\
            }ifelse\n\
        }forall\n\
    }forall\n\
}bind def\n\
%%%%EndProlog\n\
[\n",
                            CS_bbX,CS_bbY);
   }
}



/********************************************************************/
/***        The heart of the program:                             ***/
/***        Approximation of the outline by Bezier curves         ***/
/***                                                              ***/

{int x0,y0,x,y,dx,dy,i,j,n,k,m,mm,p,j0,j1,c=0,len,I,maxm;
 t_point *crv;
 int x1,y1,x2,y2,x3,y3,dx1,dx2,dx3,dy1,dy2,dy3,notfirst;
 char *oline; int olen; double sf=ScaleFactor;
 int X1,Y1,X2,Y2,X3,Y3;

  maxm = (Type1CS ? 80 : 40);

  for( m=i=0; i<nCurves; i++ )if (curve_len[i] > m) m = curve_len[i];
  crv = (t_point *)malloc( m * sizeof(t_point) );
  if( ! AllowNewLine ) oline = (char *)malloc( 2*m + 100 ); 

  for( i=0; i<nCurves; i++ ){ len=curve_len[i];

#define _putc_(ch)  {putchar(ch);\
                         if(SeparateOutput)fputc(ch,out_body);\
                         if(Proof&&(!Type1CS))fputc(ch,out_proof);\
                    }

#define _put_70_(ch)  _putc_(ch);\
                      if(++c >= 70){\
                         printf("\\\n");\
                         if(SeparateOutput)fprintf(out_body,"\\\n");\
                         if(Proof&&(!Type1CS))fprintf(out_proof,"\\\n");\
                         c=0;\
                      }\

#define _put_69_(ch)  _putc_(ch);\
                      if(++c >= 70){\
                         printf("\n");\
                         if(SeparateOutput)fprintf(out_body,"\n");\
                         if(Proof&&(!Type1CS))fprintf(out_proof,"\n");\
                         c=0;\
                      }\

     if( ! Type1CS ){
       if( AllowNewLine ){ _put_70_('('); }
       else olen=0;
     }
     else{       /* try to approximate a round (more or less) point */

       int mx=bbWidth, Mx=0, my=bbHeight,My=0;
       int x,y, x0,x1,x2,x3,x4, y0,y1,y2,y3,y4;
       int x01,y01, x12,y12, x23,y23, x34,y34;
       int j0,j1,j2,j3,j4,j5,j6,j7; int R,mR=10000,MR=0;

       /*   j2  j1   */
       /* j3      j0 */
       /*            */
       /* j4      j7 */
       /*   j5  j6   */

       for( j=0; j<len; j++ ){R=_2cr[i][j]; if(R>MR)MR=R; if(R<mR)mR=R;}

       if( (curve_dep[i]&1)==0 && len*sf < 200 && MR<3*mR ){
         x0=curve[i][0].x; y0=curve[i][0].y;
         for( j=0; j<len; j++ ){
            x=curve[i][j].x; y=curve[i][j].y;
            if(x<mx){mx=x; j4=j3=j;}else if(x==mx)j4=j;
            if(x>Mx){Mx=x; j0=j7=j;}else if(x==Mx)j0=j;
            if(y<my){my=y; j6=j5=j;}else if(y==my)j6=j;
            if(y>My){My=y; j2=j1=j;}else if(y==My)j2=j;
         }
         if(x0==mx){
            for(j=j2;j<len;j++){x=curve[i][j].x;if(x==mx){j3=j;break;}}
            for(j=j5;j>=0; j--){x=curve[i][j].x;if(x==mx){j4=j;break;}}
         }
         if(y0==my){
            for(j=j4;j<len;j++){y=curve[i][j].y;if(y==my){j5=j;break;}}
            for(j=j7;j>=0; j--){y=curve[i][j].y;if(y==my){j6=j;break;}}
         }
         if(x0==Mx){
            for(j=j6;j<len;j++){x=curve[i][j].x;if(x==mx){j7=j;break;}}
            for(j=j1;j>=0; j--){x=curve[i][j].x;if(x==mx){j0=j;break;}}
         }
         if(y0==My){
            for(j=j0;j<len;j++){y=curve[i][j].y;if(y==my){j1=j;break;}}
            for(j=j3;j>=0; j--){y=curve[i][j].y;if(y==my){j2=j;break;}}
         }

         x0=curve[i][j0].x; y0=curve[i][j0].y;

         if(j1<=j2)j=(j1+j2)/2; else{j=(j1+j2+len)/2; if(j>=len)j-=len;}
         y1=My; x1=curve[i][j].x;

         if(j3<=j4)j=(j3+j4)/2; else{j=(j3+j4+len)/2; if(j>=len)j-=len;}
         x2=mx; y2=curve[i][j].y;

         if(j5<=j6)j=(j5+j6)/2; else{j=(j5+j6+len)/2; if(j>=len)j-=len;}
         y3=my; x3=curve[i][j].x;

         x4=curve[i][j7].x; y4=curve[i][j7].y;

         if(j0<=j1)j=(j0+j1)/2; else{j=(j0+j1+len)/2; if(j>=len)j-=len;}
         x01=curve[i][j].x; y01=curve[i][j].y;

         if(j2<=j3)j=(j2+j3)/2; else{j=(j2+j3+len)/2; if(j>=len)j-=len;}
         x12=curve[i][j].x; y12=curve[i][j].y;

         if(j4<=j5)j=(j4+j5)/2; else{j=(j4+j5+len)/2; if(j>=len)j-=len;}
         x23=curve[i][j].x; y23=curve[i][j].y;

         if(j6<=j7)j=(j6+j7)/2; else{j=(j6+j7+len)/2; if(j>=len)j-=len;}
         x34=curve[i][j].x; y34=curve[i][j].y;

         CS_point(x0,y0); CS_cmd( CSC_rmoveto );
         if( Proof )fprintf(out_proof,"[[%d %d]\n", CS_X, CS_Y );

         /*   p0          p'          p"         p1                */
         /*     (p0+p')/2   (p'+p")/2   (p"+p1)/2                  */
         /*        (p0+2p'+p")/4  (p'+2p"+p1)/4                    */
         /*            p01 = (p0+3p'+3p"+p1)/8                     */
         /*            x01 = (Mx+3Mx+3x"+x1)/8 => 3x"=8x01-4Mx-x1  */
         /*            y01 = (y0+3y'+3My+My)/8 => 3y'=8y01-4My-y0  */

         CS_vpoint((8*y01-4*My-y0)/3);
                                    if(Proof)fprintf(out_proof,"[%d %d",CS_X,CS_Y);
         CS_point( (8*x01-4*Mx-x1)/3, My);
                                    if(Proof)fprintf(out_proof," %d %d",CS_X,CS_Y);
         CS_hpoint(x1);             if(Proof)fprintf(out_proof," %d %d]\n",CS_X,CS_Y);
         CS_cmd( CSC_vhcurveto );

         /*   p1          p'          p"         p2                */
         /*     (p1+p')/2   (p'+p")/2   (p"+p2)/2                  */
         /*        (p1+2p'+p")/4  (p'+2p"+p2)/4                    */
         /*            p12 = (p1+3p'+3p"+p2)/8                     */
         /*            x12 = (x1+3x'+3mx+mx)/8 => 3x'=8x12-4mx-x1  */
         /*            y12 = (My+3My+3y"+y2)/8 => 3y"=8y12-4My-y2  */


         CS_hpoint((8*x12-4*mx-x1)/3);
                                    if(Proof)fprintf(out_proof,"[%d %d",CS_X,CS_Y);
         CS_point( mx, (8*y12-4*My-y2)/3);
                                    if(Proof)fprintf(out_proof," %d %d",CS_X,CS_Y);
         CS_vpoint(y2);             if(Proof)fprintf(out_proof," %d %d]\n",CS_X,CS_Y);
         CS_cmd( CSC_hvcurveto );

         /*   p2          p'          p"         p3                */
         /*     (p2+p')/2   (p'+p")/2   (p"+p3)/2                  */
         /*        (p2+2p'+p")/4  (p'+2p"+p3)/4                    */
         /*            p23 = (p2+3p'+3p"+p3)/8                     */
         /*            x23 = (mx+3mx+3x"+x3)/8 => 3x"=8x23-4mx-x3  */
         /*            y23 = (y2+3y'+3my+my)/8 => 3y'=8y23-4my-y2  */

         CS_vpoint((8*y23-4*my-y2)/3);
                                    if(Proof)fprintf(out_proof,"[%d %d",CS_X,CS_Y);
         CS_point( (8*x23-4*mx-x3)/3, my);
                                    if(Proof)fprintf(out_proof," %d %d",CS_X,CS_Y);
         CS_hpoint(x3);             if(Proof)fprintf(out_proof," %d %d]\n",CS_X,CS_Y);
         CS_cmd( CSC_vhcurveto );

         CS_hpoint((8*x34-4*Mx-x3)/3);
                                    if(Proof)fprintf(out_proof,"[%d %d",CS_X,CS_Y);
         CS_point( Mx, (8*y34-4*my-y4)/3);
                                    if(Proof)fprintf(out_proof," %d %d",CS_X,CS_Y);
         CS_vpoint(y4);             if(Proof)fprintf(out_proof," %d %d]\n",CS_X,CS_Y);
         CS_cmd( CSC_hvcurveto );

         CS_cmd( CSC_closepath );   if(Proof)fprintf(out_proof,"]\n");
         continue;
       }
     }

     /* find the longest straight (more or less) segment on curve[i] */
     mm=4; j1=0;
     for( j=0; j<len; j++ ){
        for(n=2;n<5;n++){
           /* try multiples of n */
           x0=curve[i][j].x; y0=curve[i][j].y; dx=dy=0;
           for(  m=0;  m*3<len;  m+=n, x0=x, y0=y ){
              k=j+m+n; if(k>=len)k-=len;
              x=curve[i][k].x; y=curve[i][k].y;
              if(m==0){ dx=x-x0; dy=y-y0; continue; }
              if( x-x0 != dx || y-y0 !=dy )break;
           }
           if(m>mm){j1=j; mm=m;}
        }
     }
     j0=j1+mm; if(j0>=len)j0-=len;

     for( k=0,j=j0; k<len; k++,j++ ){ if(j>=len)j=0; crv[k] = curve[i][j]; }
     j1 -= j0; if(j1<0)j1+=len;

     j=0;

     x0 = crv[0].x; y0 = crv[0].y;        /* the initial point */
     transform( &(crv[0]), &x0, &y0 );

#define __put_k_84__ if(k>91)k++;\
                     if( AllowNewLine ){ _put_70_(k); }\
                     else oline[ olen++ ] = k;

     if( ! Type1CS ){
        k = (n=x0/84) + 42; __put_k_84__
        k =   x0-84*n + 42; __put_k_84__
        k = (m=y0/84) + 42; __put_k_84__
        k =   y0-84*m + 42; __put_k_84__
     }
     else{ CS_point(x0,y0); CS_cmd( CSC_rmoveto );
        if( Proof )fprintf(out_proof,"[[%d %d]\n", CS_X, CS_Y );
     }

     while( j<j1 ){ 
        x0 = crv[j].x; y0=crv[j].y;

        notfirst=NO;

        for( m=4; m<40; m++ ){

           if( j+3*m >= len )break;
           if( j+3*m > j1+5 )break;
           if( j1 >= j+3*m && j+3*m > j1-9 )continue;
           x1 = crv[j+m].x;      y1 = crv[j+m].y;      dx1=x1-x0;  dy1=y1-y0;
           x2 = crv[j+m+m].x;    y2 = crv[j+m+m].y;    dx2=x2-x1;  dy2=y2-y1;
           x3 = crv[j+m+m+m].x;  y3 = crv[j+m+m+m].y;  dx3=x3-x2;  dy3=y3-y2;

           p = dx1*dx3 + dy1*dy3; 
           if( notfirst && 2*p*p < (dx1*dx1 + dy1*dy1)*(dx3*dx3 + dy3*dy3) )break;
           notfirst=YES;
           p = 2*x1 - (x0+x2)/2; x2 = 2*x2 - (x3+p)/2; x1 = p;
           p = 2*y1 - (y0+y2)/2; y2 = 2*y2 - (y3+p)/2; y1 = p;

           dx1=x1-x0;  dy1=y1-y0; vector_transform(dx1,dy1,&dx1,&dy1);
           dx2=x2-x1;  dy2=y2-y1; vector_transform(dx2,dy2,&dx2,&dy2);
           dx3=x3-x2;  dy3=y3-y2; vector_transform(dx3,dy3,&dx3,&dy3);

           if( ! Type1CS ){
              if( ABS(dx1)>38 )break;  if( ABS(dy1)>38 )break;
              if( ABS(dx2)>38 )break;  if( ABS(dy2)>38 )break;
              if( ABS(dx3)>38 )break;  if( ABS(dy3)>38 )break;

              cc[0] = b2_int(dx1);  cc[1] = b2_int(dy1);
              cc[2] = b2_int(dx2);  cc[3] = b2_int(dy2);
              cc[4] = b2_int(dx3);  cc[5] = b2_int(dy3);
           }
           else{
              if( ABS(dx1*sf)>105 )break;  if( ABS(dy1*sf)>105 )break;
              if( ABS(dx2*sf)>105 )break;  if( ABS(dy2*sf)>105 )break;
              if( ABS(dx3*sf)>105 )break;  if( ABS(dy3*sf)>105 )break;

              X1=x1; Y1=y1; X2=x2; Y2=y2; X3=x3; Y3=y3;
           }
           
           mm = m;
        }
        if( ! Type1CS ){
           for( k=0; k<6; k++ ){
              if( AllowNewLine ){ _put_70_(cc[k]); }
              else oline[ olen++ ] = cc[k];
           }
        }
        else{
              CS_point(X1,Y1); if( Proof )fprintf(out_proof,"[%d %d",   CS_X,CS_Y);
              CS_point(X2,Y2); if( Proof )fprintf(out_proof," %d %d",   CS_X,CS_Y);
              CS_point(X3,Y3); if( Proof )fprintf(out_proof," %d %d]\n",CS_X,CS_Y);
              CS_cmd( CSC_rrcurveto );
        }

        j += (3*mm);

     }
    if(! Type1CS ){
     if( AllowNewLine ){ _put_69_(')'); _put_69_('C'); }
     else{
        int w = 71;         /* the desired length of line in the output */
        int Use_A = NO;     /* use the ps command A defined in Prolog   */
        if( olen+3 > w ) Use_A = YES;
        else if( olen+3 > w - c ){ _putc_('\n'); c=0; }
        if( Use_A ){
           if( c > w-10 ){ _putc_('\n'); c=0; }
           _putc_('['); _putc_('('); c+=2;
           for( k=0; k<olen; k++ ){
              _putc_(oline[k]);
              if(++c>=w){
                 if(k==olen-1)break;
                 _putc_(')'); _putc_('\n'); _putc_('('); c=1;
              }
           }
           _putc_(')'); _putc_(']'); _putc_('A');
           c+=3; if(c>w){_putc_('\n'); c=0;}
        }
        else{
           _putc_('(');
           for( k=0; k<olen; k++ )_putc_(oline[k]);
           _putc_(')'); _putc_('C');
           c += (olen+3);
        }
     }
    } /* matches to  "if(! Type1CS ){" */
    else{ CS_cmd( CSC_closepath );
       if( Proof )fprintf(out_proof,"]\n");
    }
  }

 if( ! Type1CS ){
  printf(" f\n%%%%Trailer\n%%%%EOF\n");
  if( SeparateOutput ) fprintf(out_body," f\n");
 }
 else{ CS_cmd( CSC_endchar );
   if(!CS_bin)puts(">"); 
   else{
     printf("%d RD ",CS_buf_pt);
     fwrite(CS_buf,CS_buf_pt,1,stdout);
/*     for( i=0; i<CS_buf_pt; i++ )printf("%a",CS_buf[i]);*/
     printf(" ND\n");
   }
 }

 if( Proof ){ int x,y,len,r,a,j,i=0; 
              len=curve_len[i]; j=0; x=curve[i][j].x; y=curve[i][j].y;
              r=_2cr[i][j]; a=_2ca[i][j]; x*=ScaleFactor; y*=ScaleFactor;
              r=2*r*ScaleFactor;
     if( Type1CS )fprintf(out_proof,"]");
     fprintf(out_proof," f\n\
0 0 1 setrgbcolor newpath %d %d moveto %d %d %d 0 %d arc stroke\n\
0 0 1 setrgbcolor newpath %d %d moveto %d %d 1 0 360 arc stroke\n\
%%%%Trailer\n%%%%EOF\n", x+r, y, x,y,r,a, x+1,y,x,y);
 }


}

}
/***********************************************************/
/***********************************************************/
/****                                                   ****/
/****            E N D    O F    M A I N (  )           ****/
/****                                                   ****/
/***********************************************************/
/***********************************************************/

int b2_int( int c ){  c+=80; if(c>90)c+=3;  return c; }

/*---------------------------------------------------------*/

void transform( t_point *p, int *x, int *y ){
    *x = (mat._10) + (mat._11)*(p->x) + (mat._12)*(p->y);
    *y = (mat._20) + (mat._21)*(p->x) + (mat._22)*(p->y);
}
/*---------------------------------------------------------*/

void vector_transform( int x,int y, int *px, int *py ){
    *px = (mat._11)*x + (mat._12)*y;
    *py = (mat._21)*x + (mat._22)*y;
}

/*---------------------------------------------------------*/

void copy_matrix( t_matrix *src, t_matrix *dst ){
    dst->_10 = src->_10; dst->_11 = src->_11; dst->_12 = src->_12;
    dst->_20 = src->_20; dst->_21 = src->_21; dst->_22 = src->_22;
}

/*---------------------------------------------------------*/

void get_matrix( char *p ){char c; t_matrix *mp;
  while( c=*p++ ){
    switch(c){
      case '|': mp=&matV; break;
      case '-': mp=&matH; break;
      case '+': mp=&matC; break;
      case 'r': mp=&matr; break;
      case 'R': mp=&matR; break;
      default: err("'|', '-', '+', 'r', or 'R' are expected after -m"); break;
    }
    compose_matrices( &mat, mp, &mat1 );
    copy_matrix( &mat1, &mat );
  }
}

/*---------------------------------------------------------*/

void compose_matrices( t_matrix *A, t_matrix *B, t_matrix *C ){
/*                                                                        */
/* C(x,y) = A(B(x,y))                                                     */
/*        = A( B10 + B11*x + B12*y, B21 + B21*x + B22*y                   */
/*        = [A10 + A11*(B10 + B11*x + B12*y) + A12*(B21 + B21*x + B22*y), */
/*           A20 + A21*(B10 + B11*x + B12*y) + A22*(B21 + B21*x + B22*y)] */

  C->_10 = (A->_11)*(B->_10) + (A->_12)*(B->_21) + (A->_10);
  C->_11 = (A->_11)*(B->_11) + (A->_12)*(B->_21);
  C->_12 = (A->_11)*(B->_12) + (A->_12)*(B->_22);
  C->_20 = (A->_21)*(B->_10) + (A->_22)*(B->_21) + (A->_20);
  C->_21 = (A->_21)*(B->_11) + (A->_22)*(B->_21);
  C->_22 = (A->_21)*(B->_12) + (A->_22)*(B->_22);
}

/*---------------------------------------------------------*/
#define bz_n_max 60
#define pg_n_max 60

double bz_x[bz_n_max+1], bz_y[bz_n_max+1];
double pg_x[pg_n_max+1], pg_y[pg_n_max+1];

double good_approx( t_point *crv, int len, int j0, int j1, 
          int x0,int y0,int x1,int y1,int x2,int y2,int x3,int y3 ){

   int i,k,j,jj,bz_n,pg_n,sw,X0,Y0,X1,Y1; double d,d0,d1,e,dx,dy;
   double ax,bx,cx, ay,by,cy,t;


   pg_n = 1;  pg_x[0] = X0 = crv[j0].x;  pg_y[0] = Y0 = crv[j0].y;
   if( j1<j0 ) j1 += len;
   for( jj=j0+1; jj<=j1; jj++ ){
      j=jj; if(j==len)j=0;
      X1 = crv[j].x; Y1 = crv[j].y;
      if( ABS(X1-X0)==1 ){
         pg_x[pg_n] = (X0+X1)*0.5;  pg_y[pg_n++] = (Y0+Y1)*0.5;
         pg_x[pg_n] = X1;           pg_y[pg_n++] = Y1;
      }
      else{
         pg_x[pg_n] = (X0+X0+X1)/3.;  pg_y[pg_n++] = (Y0+Y0+Y1)/3.;
         pg_x[pg_n] = (X0+X1+X1)/3.;  pg_y[pg_n++] = (Y0+Y1+Y1)/3.;
         pg_x[pg_n] = X1;             pg_y[pg_n++] = Y1;
      }
      X0=X1; Y0=Y1;
   }
   pg_n--;

   if( pg_n > pg_n_max )err("ierr pg_n");

   bz_n = 2*pg_n; if( bz_n > bz_n_max )bz_n = bz_n_max;

   cx = (x1-x0)*3;     cy = (y1-y0)*3;
   bx = (x2-x1)*3-cx;  by = (y2-y1)*3-cy;
   ax = x3-x0-bx-cx;   ay = y3-y0-by-cy;

   for( k=0;  k <= bz_n;  k++ ){ t = ((double)k)/((double)bz_n);
      bz_x[k] = ((ax*t + bx)*t + cx)*t + x0;
      bz_y[k] = ((ay*t + by)*t + cy)*t + y0;
   }

   k=0; i=1; d=d0=0; sw=0;
   while( YES ){

/*      printf("k=%d i=%d d=%f d0=%f d1=%f sw=%d\n", k,i,d,d0,d1,sw); */

      dx = pg_x[i] - bz_x[k];  dy = pg_y[i] - bz_y[k];
      d1 = Sqrt_( dx*dx + dy*dy );
      if( d1 > d ) d = d1;

      if( k == bz_n && i == pg_n )break;
      if( k == bz_n ){ i++; continue; }
      if( i == pg_n ){ k++; continue; }
      
      switch(sw){
        case 0:  if( d1 < d0 ) i++;  else{ sw=1; k++; }  break;
        case 1:  if( d1 < d0 ) k++;  else{ sw=0; i++; }
      }
      d0 = d1;
   }
   /* d is the distance between the polygonal curve crv[j0]..crv[j1] */
   /*   and the Bezier curve                                         */


   return d;

}
/*---------------------------------------------------------*/
void out_pxl( void ){ int x,y,c,r;
  for( x=0; x<2*Width+2; x++ )putchar('-');
  putchar('\n');
  for( y=0; y<Height; y++ ){
    putchar('|');
    for( x=0; x<Width; x++ ){
      c=(COLOR & pxl[y][x]); r=(REGION & pxl[y][x]);
      if( r>15 )printf(" "); else printf("%x",r);
      if( c==WHITE )putchar(' '); else putchar('*');
    }
    putchar('|');putchar('\n');
  }
  for( x=0; x<2*Width+2; x++ )putchar('-');
  putchar('\n');
}
/*---------------------------------------------------------*/
void out_curves(void){ int i,j;
  printf("nCurves = %d\n",nCurves);
  for(i=0; i<nCurves; i++ ){
    printf("curve%d: length=%d depth=%d OuterCurve=%d\n",
           i,curve_len[i],curve_dep[i], OuterCurve[i]);
    for( j=0; j<curve_len[i]; j++ ){
      printf("(%d,%d)-",curve[i][j].x,curve[i][j].y);
    }
    putchar('\n');
  }
}
/*---------------------------------------------------------*/
void err( char *s ){ puts(s); exit(9); }
void err2( char *s1, char *s2 ){ printf("%s %s\n",s1,s2); exit(9); }
/*---------------------------------------------------------*/
void push( int x0, int x1, int y ){
  if( SP+3 > StackSize )err("stack overflow");
  stack[SP++] = x0; stack[SP++] = x1; stack[SP++] = y;
/*  printf("push x0=%d x1=%d y=%d;  new SP = %d\n",x0,x1,y,SP); */
}
void pop( int *x0, int *x1, int *y ){
  if( SP-3 < 0 )err("stack ierr");
  *y = stack[--SP]; *x1 = stack[--SP]; *x0 = stack[--SP];
/*  printf("pop  x0=%d x1=%d y=%d;  new SP = %d\n",*x0,*x1,*y,SP); */
}



/*----------------------------------------------------------*/
/*----------------------------------------------------------*/
/*----------------------------------------------------------*/
/* Fill the region containing (x,y) in color c              */
/* tracing all newly found curves                           */
/* Set the SCANNED-bit to 1 for all pixels of this region   */
/* In fact, c is 1 + the number of the outer boundary curve */

void fill( int x, int y, int c, int depth ){
  int x0,x1,xx,yy,xx0,xx1,out_crv=c-1;

  c = c | (COLOR & pxl[y][x]);
  x0 = fill_line( x,y,-1, c|SCANNED );
  x1 = fill_line( x,y, 1, c|SCANNED );
  SP=0; push(x0,x1,y);

  while( SP>0 ){
    pop(&x0, &x1, &y);

    if( x1<Width && (REGION & pxl[y][x1]) == REGION ){
      if(debug){printf(
        " Trace curve at (%d,%d) (%d,%d) with %04x %04x \n before tracing:\n", 
                                      x1-1,y,x1,y,c,nCurves+1); out_pxl();}
      if( nCurves == MaxNumCurves )err("too many curves");
      trace( x1-1, y, c, x1, y, nCurves+1, nCurves ); 
      if(debug){
        printf(" after tracing:\n");
        out_pxl();
        printf("pt_hp=%d PtHeapSize=%d\n", pt_hp, PtHeapSize);
      }
      IntPt[ nCurves ].x = x1; IntPt[ nCurves ].y = y;
      OuterCurve[ nCurves ] = out_crv;
      curve_dep[ nCurves++ ] = depth;
    }
    if( x0 >= 0 && (REGION & pxl[y][x0]) == REGION ){
      if(debug){printf(
        " Trace curve at (%d,%d) (%d,%d) with %04x %04x \n before tracing:\n", 
                                       x1-1,y,x1,y,c,nCurves+1); out_pxl();}
      if( nCurves == MaxNumCurves )err("too many curves");
      trace( x0+1, y, c, x0, y, nCurves+1, nCurves );
      if(debug){
        printf(" after tracing:\n");
        out_pxl();
        printf("pt_hp=%d PtHeapSize=%d\n", pt_hp, PtHeapSize);
      }
      IntPt[ nCurves ].x = x0; IntPt[ nCurves ].y = y;
      OuterCurve[ nCurves ] = out_crv;
      curve_dep[ nCurves++ ] = depth;
    }

    for( yy=y-1; yy<=y+1; yy+=2 ){
      if( yy<0 || yy>=Height )continue; 
      for( xx=x0+1; xx < x1; xx++ ){ 
        if( (COLOR & c) != (COLOR & pxl[yy][xx]) )continue;
        if( SCANNED & pxl[yy][xx] )continue;
        xx0 = fill_line(xx,yy,-1,c|SCANNED);
        xx1 = fill_line(xx,yy, 1,c|SCANNED);
        push(xx0,xx1,yy);
        xx = xx1;
      }
    }
  }
}

/*---------------------------------------------------------*/
/* returns the first x such that color(x,y) != color(c)    */
/* dir > 0  => fill to the right                           */
/* dir < 0  => fill to the left                            */
/*                                 used in fill()          */

int fill_line( int x, int y, int dir, int c ){

  if( (COLOR & c) != (COLOR & pxl[y][x]) )err("ierr4");
  if( dir>0 ) dir=1; else dir=-1;
  while( YES ){
    pxl[y][x] = c; x += dir;
    if( x>=Width || x<0 )return x;
    if( (COLOR & c) != (COLOR & pxl[y][x]) )return x;
  }
}

/*----------------------------------------------------------------------*/
/* Trace the curve which starts between the pixels (x1,y1) and (x2,y2). */
/* These pixels should be neighboring and of opposite colors.           */
/* The curve is always oriented so that the white region is to the left */
/* Color 1-pixel borders to each side of the curve in colors c1 and c2  */
/* but the SCANNED-bit is not changed while coloring                    */
/*                                                                      */

void trace( int x1,int y1,int c1,int x2,int y2,int c2,int nc ){
  int wx,wy, bx,by, wx0,wy0, bx0,by0, wwx,wwy, bbx,bby, dx,dy, cw,cb;
  t_point *p; word *v;

  int count=0;


  if( (COLOR & pxl[y1][x1]) == (COLOR & pxl[y2][x2]) )err("ierr0");

  c1 = (COLOR & pxl[y1][x1]) | (REGION & c1);
  c2 = (COLOR & pxl[y2][x2]) | (REGION & c2);

  if( COLOR & pxl[y1][x1] ){ wx=x1; wy=y1; cw=c1; bx=x2; by=y2; cb=c2; }
  else                     { wx=x2; wy=y2; cw=c2; bx=x1; by=y1; cb=c1; }
  wx0=wx; wy0=wy; bx0=bx; by0=by;

  p = curve[nc] = pt_heap + pt_hp;  curve_len[nc] = 0;

  if(debug){ int x,y;
    printf("(x1,y1)=(%d,%d)  (x2,y2)=(%d,%d)\n",x1,y1,x2,y2);
    for( y=y1-5; y<=y2+5; y++ ){if(y<0)continue; if(y>=Height)break;
      for( x=x1-5; x<=x2+5; x++ ){if(x<0)continue; if(x>=Width)break;
        if( (pxl[y][x]&COLOR) == WHITE )putchar('.'); else putchar('*');
        if(x==x1&&y==y1)putchar('1');
        else if(x==x2&&y==y2)putchar('2'); else putchar(' ');
      }
      putchar('|');putchar('\n');
    }
  }

  if(debug){ printf("w0=(%d,%d)  b0=(%d,%d)\n", wx0,wy0,bx0,by0); }

  while( YES ){
    if( bx<1 || by<1 || bx > Width-2 || by > Height-2 )err("ierr2");

    p->x = (wx+bx); p->y = (wy+by);
    if(debug)if(pt_hp<5290)printf("%d -> (%d,%d) \n",pt_hp, p->x, p->y );
             else{ out_pxl(); exit(0); }
    curve_len[nc]++;  p++;  pt_hp++;
    if( pt_hp == PtHeapSize )err("point heap overflow");

    /* w and b are current white and black points  */
    /* let's find next points ww and bb            */

    /*  w              d = (b-w)*i,                */
    /* --->  (dx + i*dy) = {(bx-wx) + i*(by-wy)}*i */
    /*  b                = -(by-wy) + i*(bx-wx)    */

    dx = wy-by; dy = bx-wx;   /* direction of the curve */

    if( (dx<0 ? -dx : dx) + (dy<0 ? -dy : dy) != 1 ) err("ierr1");

    /*   w  w+d   */
    /* ---------> */
    /*   b  b+d   */

    if( COLOR & pxl[by+dy][bx+dx] ){

      /* b+d is white (and no 2x2 chessboards!) */
      /* this means:     */
      /*                 */
      /*   w        w+d  */
      /*  -------        */
      /*   b    |   b+d  */
      /*     bb | ww     */

      wwx = bx+dx; wwy = by+dy;  /* ww = b+d */
      bbx = bx;    bby = by;     /* bb = b   */

      v=&(pxl[wy+dy][wx+dx]);*v=((*v)&SCANNED)|cw; /* color(w+d) = cw */
      v=&(pxl[by+dy][bx+dx]);*v=((*v)&SCANNED)|cw; /* color(b+d) = cw */
      v=&(pxl[wy][wx]);      *v=((*v)&SCANNED)|cw; /* color(w )  = cw */
      v=&(pxl[by][bx]);      *v=((*v)&SCANNED)|cb; /* color(b )  = cb */
    }
    else if( COLOR & pxl[wy+dy][wx+dx] ){

      /* b+d is black and w+d is white */
      /* this means:    */
      /*                */
      /*   w     ww     */
      /*  ---------->   */
      /*   b     bb     */
      /*                */

      wwx = wx+dx; wwy = wy+dy;  /* ww = w+d */
      bbx = bx+dx; bby = by+dy;  /* bb = b+d */

      v=&(pxl[wy+dy][wx+dx]);*v=((*v)&SCANNED)|cw; /* color(w+d) = cw */
      v=&(pxl[by+dy][bx+dx]);*v=((*v)&SCANNED)|cb; /* color(b+d) = cb */
      v=&(pxl[wy][wx]);      *v=((*v)&SCANNED)|cw; /* color(w )  = cw */
      v=&(pxl[by][bx]);      *v=((*v)&SCANNED)|cb; /* color(b )  = cb */
    }
    else{

      /* b+d is black and w+d is black */
      /* this means:    */
      /*                */
      /*    ww | bb     */
      /*   w   |   w+d  */
      /*  ------        */
      /*   b       b+d  */

      wwx = wx;    wwy = wy;     /* ww = w   */
      bbx = wx+dx; bby = wy+dy;  /* bb = w+d */

      v=&(pxl[wy+dy][wx+dx]);*v=((*v)&SCANNED)|cb; /* color(w+d) = cb */
      v=&(pxl[by+dy][bx+dx]);*v=((*v)&SCANNED)|cb; /* color(b+d) = cb */
      v=&(pxl[wy][wx]);      *v=((*v)&SCANNED)|cw; /* color(w )  = cw */
      v=&(pxl[by][bx]);      *v=((*v)&SCANNED)|cb; /* color(b )  = cb */
    }
    /* the points ww and bb are found */

    if(debug){ printf("ww=(%d,%d)  bb=(%d,%d)\n", wwx,wwy,bbx,bby); }
    if( wwx==wx0 && wwy==wy0 && bbx==bx0 && bby==by0 )break;
                                        /* the curve is finished */
    wx=wwx; wy=wwy; bx=bbx; by=bby;
  }
}
/*-----------------------------------------------------------------*/

word  string2word( byte *s ){ word w=0; byte *p;
    p = ((byte *)(&w));
    if( BMP_ByteOrder ){         p[0]=s[0]; p[1]=s[1]; }
    else{ p += (sizeof(word)-2); p[0]=s[1]; p[1]=s[0]; }
    return w;
}

dword string2dword( byte *s ){ dword w=0; byte *p;
    p = ((byte *)(&w));
    if( BMP_ByteOrder ){      p[0]=s[0];p[1]=s[1];p[2]=s[2];p[3]=s[3];}
    else{p+=(sizeof(word)-4); p[0]=s[3];p[1]=s[2];p[2]=s[1];p[3]=s[0];}
    return w;
}

/*-----------------------------------------------------------------*/
/* Sqrt_: Replaces the standard function  sqrt  to simplify        */
/*        the compilation. Now the math library isn't needed.      */

double Sqrt_( double a ){ double prec=1E-10; double x = a; double y;

  /* Newton's method:                                              */
  /*   x = x - f(x)/f'(x)   where   f(x) = x^2 - a,  f'(x) = 2x    */
   
  if( x < 0. )err("ierr sqrt");
  while( y = x*x - a, !(-prec<y && y<prec) ) x -= 0.5*y/x;
  return x;
}
/****-----------------------------------------------------------****/
/****                          Type1 CharString Output support  ****/
/****                                                           ****/


void CS_vpoint( int y ){int Y;
   Y = y*ScaleFactor; CS_num( Y - CS_Y ); CS_Y = Y;
}

void CS_hpoint( int x ){int X;
   X = x*ScaleFactor; CS_num( X - CS_X ); CS_X = X;
}

void CS_point( int x, int y ){int X,Y;
   X = x*ScaleFactor;  Y = y*ScaleFactor;
   CS_num( X - CS_X ); CS_num( Y - CS_Y );
   CS_X = X; CS_Y = Y;
}
/*------*/

void CS_num( int n ){ byte v,w; int a; byte *p;
  if( -107 <= n && n <= 107 )CS_byte( n + 139 );
  else if( 108 <= n && n <= 1131 ){ a=n-108;
      CS_byte( (a>>8)+247 ); CS_byte( a&255 );
  }
  else if( -1131 <= n && n <= -108 ){ a=-108-n;
      CS_byte( (a>>8)+251 ); CS_byte( a&255 );
  }
  else{ CS_byte(255); p = (byte *)(&n);
      CS_byte(p[3]);CS_byte(p[2]);CS_byte(p[1]);CS_byte(p[0]);
  }
#ifdef _CS_debug_
  printf("(%d) ",n);
#endif
}
/*------*/
word CS_r  =  4330;
word CS_c1 = 52845;
word CS_c2 = 22719;
byte CS_hex[3];
byte CS_pos = 0;



void CS_byte( byte plain ){
   byte cipher;                  /* reproduced from T1Format.pdf */
   cipher = (plain^(CS_r >> 8));
   CS_r = (cipher + CS_r)*CS_c1 + CS_c2;

#ifdef _CS_debug_
   printf("%d[%d]",plain,cipher);
#else
   if( !CS_bin ){
      printf("%02x",cipher);
      if(++CS_pos > 35){putchar('\n'); CS_pos = 0;}
   }
   else{
      if( CS_buf_pt == CS_buf_size )err("CS_buf overflow");
      CS_buf[CS_buf_pt++]=cipher;
   }
#endif
}
/*------*/

void CS_cmd( byte c ){ CS_byte( c ); 
#ifdef _CS_debug_
   switch(c){
     case CSC_hsbw:       puts("hsbw"); return;
     case CSC_hstem:      puts("hstem"); return;
     case CSC_vstem:      puts("vstem"); return;
     case CSC_endchar:    puts("endchar"); return;
     case CSC_rlineto:    puts("rlineto"); return;
     case CSC_hlineto:    puts("hlineto"); return;
     case CSC_vlineto:    puts("vlineto"); return;
     case CSC_rrcurveto:  puts("rrcurveto"); return;
     case CSC_closepath:  puts("closepath"); return;
     case CSC_rmoveto:    puts("rmoveto"); return;
     case CSC_hmoveto:    puts("hmoveto"); return;
     case CSC_vmoveto:    puts("vmoveto"); return;
     default:        puts("?");
   }
#endif
}

/*==================================================================*/
void Trace2cr( void ){int i,j,x,y,r,r0,maxr,a,a0,len,xb,yb,xb0,yb0;
   int *_2cri, *_2cai;

   maxr = Width; if( Height>maxr )maxr=Height; maxr;

   for( i=0; i<nCurves; i++ ){len = curve_len[i]; r0=2; a0=180;
      _2cri=_2cr[i]; _2cai=_2ca[i]; 
      ToBlackPxl( curve[i][0].x, curve[i][0].y, &xb0, &yb0 );
      for( r=2; r<maxr; r++ ){
         if( !Check2cr(xb0,yb0,r,&a) )break;
         r0=r; a0=a;
      }
      _2cri[0]=r0; _2cai[0]=a0;

      for( j=1; j<len; j++ ){
          ToBlackPxl( curve[i][j].x, y=curve[i][j].y, &xb, &yb );
          if( xb==xb0 && yb==yb0 ){ 
             _2cri[j]=r0; _2cai[j]=a0; continue;
          }
          for( r=r0; r>2; r-- ) if( Check2cr(xb,yb,r,&a0) )break;
          if( r==2 )a0=180;
          if( r==r0 ){
             while( r<maxr ){
                if( !Check2cr(xb,yb,r,&a) )break;
                r0=r++; a0=a;
             }
          }
          else r0=r;
          _2cri[j]=r0; _2cai[j]=a0;
      }
   }
}

/*-----------------------------*/
void ToBlackPxl( int x, int y, int *xb, int *yb ){int z1,z2;
   if(x&1){
      *yb = y/2; z1=(x+1)/2; z2=(x-1)/2;
      *xb = ( pxl[*yb][z1]&COLOR == WHITE ? z2 : z1 );
   }
   else{
      *xb = x/2; z1=(y+1)/2; z2=(y-1)/2;
      *yb = ( pxl[z1][*xb]&COLOR == WHITE ? z2 : z1 );
   }
}

int PxlColor(int x, int y){
   if(x<0 || x>=Width || y<0 || y>=Height) return WHITE;
   return pxl[y][x]&COLOR;
}
/*-----------------------------*/

int Check2cr( int x0, int y0, int r, int *a ){

   int rx=r, ry=0, f=0, C0,C1,C2,C3,C4,C5,C6,C7, c0,c1,c2,c3,c4,c5,c6,c7,c8;
   int dfx = r+r+1, dfy = 1, n=0, aa[20]; double A,t;

   if( r==1 )err("ierr Check2cr");

   C0=C4=PxlColor(x0+r,y0); C1=C5=PxlColor(x0,y0+r);
   C2=C6=PxlColor(x0-r,y0); C3=C7=PxlColor(x0,y0-r);

   /* f = x^2 + y^2 - r^2                                 */
   /* f(x+1,y) = x^2 + 2x + 1 + y^2 - r^2 = f(x,y) + 2x+1 */ 
   /* f(x,y+1) = x^2 + y^2 + 2y + 1 - r^2 = f(x,y) + 2y+1 */

   /*      C1|C5      */
   /*        |        */
   /*  C6    |    C0  */
   /*  ------+------  */
   /*  C2    |    C4  */
   /*        |        */
   /*      C7|C3      */

   while( YES ){
       ry++; f+=dfy; dfy+=2;
       if( f>=dfx ){ rx--; f-=dfx; dfx-=2; }
       if( rx <= ry ) break;
       c0=PxlColor(x0+rx,y0+ry); c1=PxlColor(x0-ry,y0+rx);
       c4=PxlColor(x0+rx,y0-ry); c5=PxlColor(x0+ry,y0+rx);

       c2=PxlColor(x0-rx,y0-ry); c3=PxlColor(x0+ry,y0-rx);
       c6=PxlColor(x0-rx,y0+ry); c7=PxlColor(x0-ry,y0-rx);

       t=((double)ry)/((double)rx);
       A=((((t*t/9.-1./7.)*t*t+0.2)*t*t-1./3.)*t*t+1.)*t;  /* A=atan(t) */
       A=A*180./3.1415926536;

       if(c0!=C0)aa[n++]=A;     if(c1!=C1)aa[n++]=90+A;
       if(c2!=C2)aa[n++]=180+A; if(c3!=C3)aa[n++]=270+A;
       if(c4!=C4)aa[n++]=360-A; if(c5!=C5)aa[n++]=90-A;
       if(c6!=C6)aa[n++]=180-A; if(c7!=C7)aa[n++]=270-A; 

       if(n>2)return NO;
       C0=c0; C1=c1; C2=c2; C3=c3; C4=c4; C5=c5; C6=c6; C7=c7;
   }
   if(C0!=C5)aa[n++]=45;  if(C1!=C6)aa[n++]=135;
   if(C2!=C7)aa[n++]=225; if(C3!=C4)aa[n++]=315;
   *a = aa[1]-aa[0]; if((*a) < 0)*a = 360+(*a); if(*a>=180)*a = 360-(*a);
   return n==2;
}
