/* addg.c   Used in addglyph (to make a mayafont)   */
/*          Part of the project MayaPS v 1.0        */
#include <stdio.h>
#define YES 1
#define NO  0

FILE *bb, *ee;

void main( int argc, char *argv[] ){
   int llx,lly,urx,ury; char *gn,c,ac;
   int IsAffix=NO;

   gn=argv[1]; ac=*(argv[2]);

   if( ac=='A' || ac=='a' )IsAffix=YES;

   bb = fopen("tmp.bb","r");
   ee = fopen("tmp.ee","r");

   fscanf(bb,"%d %d %d %d", &llx, &lly, &urx, &ury );

   printf("\n/a%s %c D/w%s %d D/h%s %d D",
            gn,(IsAffix?'T':'F'),gn,urx,gn,ury);
   if( argc > 3 )printf("/A%s%sD",gn,argv[3]);
   printf(" P/m%s{GIni()A( )Z}U/g%s\n",gn,gn);
   while( (c=fgetc(ee))!=EOF )putchar(c);

   printf("V\n");
}
